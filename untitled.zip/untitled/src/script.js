// Запускаем код только после полной загрузки страницы
window.onload = function() {
    const h1Element = document.getElementsByTagName("h1")[0];
    
    // Проверяем, если элемент существует, то применяем к нему стиль
    if (h1Element) {
        h1Element.style.fontSize = "6vw";
    } else {
        console.error("Элемент h1 не найден");
    }
};
